document.getElementById('add-park-btn').addEventListener('click', function() {
    let name = document.getElementById('park-name').value;
    let description = document.getElementById('park-description').value;

    // Validar que no estén vacíos
    if (name === '' || description === '') {
        alert('Por favor, completa ambos campos.');
        return;
    }

    // Enviar datos a un archivo PHP usando AJAX
    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'agregar_zona.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            alert('Zona agregada exitosamente');
            // Recargar la página para mostrar la nueva zona
            location.reload();
        } else {
            alert('Error al agregar la zona');
        }
    };
    xhr.send('name=' + name + '&description=' + description);
});
