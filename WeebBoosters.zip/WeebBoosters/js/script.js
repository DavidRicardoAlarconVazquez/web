

fetch('https://www.googleapis.com/customsearch/v1?key=AIzaSyAU8v59dPd0ur9jfsxV6m01NwgtgQkg6e4&cx=YOUR_CX_ID&q=tu_query')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));



// Cargar comentarios del foro
function cargarComentarios() {
    fetch('cargar_comentarios.php')
        .then(response => response.text())
        .then(data => {
            document.getElementById('foro').innerHTML = data;
        });
}

// Enviar nuevo comentario
document.getElementById('form-comentario').addEventListener('submit', function (e) {
    e.preventDefault();
    const usuario = document.getElementById('usuario').value;
    const comentario = document.getElementById('comentario').value;

    fetch('guardar_comentario.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `usuario=${usuario}&comentario=${comentario}`
    })
    .then(response => response.text())
    .then(data => {
        cargarComentarios();
        document.getElementById('form-comentario').reset();
    });
});

// Cargar comentarios cuando se carga la página
window.onload = cargarComentarios;

