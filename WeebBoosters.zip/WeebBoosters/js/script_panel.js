// Función para abrir una pestaña
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;

    // Ocultar todo el contenido de las pestañas
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Remover la clase "active" de todos los enlaces de las pestañas
    tablinks = document.getElementsByTagName("a");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Mostrar el contenido de la pestaña seleccionada y agregar la clase "active"
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Abre la primera pestaña por defecto al cargar la página
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("Zonas").style.display = "block";
});
