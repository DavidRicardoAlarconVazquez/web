<?php
include 'conexiondb.php'; // Conexión a la base de datos

$sql = "SELECT id_usuario, nombre_usuario, correo_usuario FROM USUARIOS";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['nombre_usuario']}</td>
                <td>{$row['correo_usuario']}</td>
                <td>
                    <a href='editar_usuario.php?id_usuario={$row['id_usuario']}'><button>Editar</button></a>
                    <form action='eliminar_usuario.php' method='POST' style='display:inline-block;' onsubmit='return confirm(\"¿Estás seguro de que deseas eliminar este usuario?\");'>
                        <input type='hidden' name='id_usuario' value='{$row['id_usuario']}'>
                        <button type='submit'>Eliminar</button>
                    </form>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='3'>No hay usuarios registrados.</td></tr>";
}

$conn->close();
?>
