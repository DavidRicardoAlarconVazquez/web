<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['nombre_lista'])) {
    $nombre_lista = $_POST['nombre_lista'];

    // Verificar si la lista ya existe
    $sqlCheck = "SELECT * FROM lista_deseos WHERE nombre_lista = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $nombre_lista);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        // La lista ya existe
        header("Location: deseos.php?message=Error: La lista de deseos ya existe.");
        exit();
    } else {
        // Insertar la nueva lista de deseos
        $sqlInsert = "INSERT INTO lista_deseos (nombre_lista) VALUES (?)";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bind_param("s", $nombre_lista);

        if ($stmtInsert->execute()) {
            // Redireccionar después de la inserción
            header("Location: deseos.php?message=Lista de deseos creada exitosamente.");
            exit();
        } else {
            echo "Error al crear la lista: " . $conn->error;
        }
    }
}

// Cerrar la conexión
$conn->close();
?>
