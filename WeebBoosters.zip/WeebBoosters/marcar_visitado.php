<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

if (isset($_GET['id']) && isset($_GET['id_lista'])) {
    $id_zona = $_GET['id'];
    $id_lista = $_GET['id_lista'];

    // Actualizar el estado a visitado
    $sqlUpdate = "UPDATE lugar_listas SET visitado_visitaLugar = 'S' WHERE ZONAS_id_zona = ? AND LISTA_DESEOS_id_lista = ?";
    $stmt = $conn->prepare($sqlUpdate);
    $stmt->bind_param("ii", $id_zona, $id_lista);

    if ($stmt->execute()) {
        header("Location: deseos.php?id_lista=" . htmlspecialchars($id_lista) . "&message=Zona marcada como visitada.");
        exit();
    } else {
        echo "Error al marcar la zona como visitada.";
    }
    $stmt->close();
} else {
    echo "ID de zona o lista no proporcionado.";
}

$conn->close();
?>
