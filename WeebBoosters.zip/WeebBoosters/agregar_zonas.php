<?php
// Conexión a la base de datos
$host = "localhost";
$db = "inah";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);

// Verifica si hay error de conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Verifica si la solicitud es POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Asegúrate de que los campos se envíen correctamente
    $nombre_zona = isset($_POST['name']) ? $_POST['name'] : ''; // Nombre de la zona
    $descripcion_zona = isset($_POST['description']) ? $_POST['description'] : ''; // Descripción de la zona
    $lista_id = isset($_POST['lista_id']) ? $_POST['lista_id'] : 0; // ID de la lista

    // Validar que los campos no estén vacíos
    if (!empty($nombre_zona) && !empty($descripcion_zona) && $lista_id > 0) {
        
        // Aquí debes obtener el ID de la zona que estás agregando
        // Por ejemplo, puedes usar una consulta para buscarlo en la base de datos según el nombre
        $sqlBuscarZona = "SELECT id_zona FROM zonas WHERE nombre_zona = ?"; // Asegúrate de que esta consulta tenga sentido
        $stmtBuscar = $conn->prepare($sqlBuscarZona);
        
        if ($stmtBuscar) {
            $stmtBuscar->bind_param("s", $nombre_zona); // Suponiendo que estás buscando por nombre
            $stmtBuscar->execute();
            $resultado = $stmtBuscar->get_result();
            
            if ($resultado->num_rows > 0) {
                $zona = $resultado->fetch_assoc();
                $zona_id = $zona['id_zona']; // Obtiene el ID de la zona encontrada
                
                // Ahora inserta en la tabla lugar_listas
                $sql_insert_zona = "INSERT INTO lugar_listas (LISTA_DESEOS_id_lista, ZONAS_id_zona, visitado_visitaLugar) VALUES (?, ?, 'N')"; // 'N' significa que no ha sido visitado

                // Prepara la consulta
                $stmtInsertar = $conn->prepare($sql_insert_zona);
                if ($stmtInsertar) {
                    $stmtInsertar->bind_param("ii", $lista_id, $zona_id); // Un entero para ID de lista y otro para ID de zona
                    
                    if ($stmtInsertar->execute()) {
                        echo "Zona agregada exitosamente a la lista de deseos.";
                    } else {
                        echo "Error al agregar la zona a la lista de deseos: " . $stmtInsertar->error;
                    }
                    $stmtInsertar->close(); // Cierra el stmtInsertar
                } else {
                    echo "Error al preparar la consulta: " . $conn->error;
                }
            } else {
                echo "No se encontró la zona con el nombre proporcionado.";
            }

            $stmtBuscar->close(); // Cierra el stmtBuscar
        } else {
            echo "Error al preparar la consulta para buscar la zona: " . $conn->error;
        }
    } else {
        echo "Por favor completa todos los campos.";
    }
}

$conn->close();
?>
