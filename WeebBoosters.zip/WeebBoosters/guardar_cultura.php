<?php
require_once 'conexiondb.php'; // Asegúrate de que este archivo establece la conexión correctamente

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['nombreCultura']) && isset($_POST['descripcionCultura']) && isset($_POST['tipoCultura'])) {
        $nombreCultura = $_POST['nombreCultura'];
        $descripcionCultura = $_POST['descripcionCultura'];
        $tipoCultura = $_POST['tipoCultura'];

        // Verificar si ya existe una cultura con el mismo nombre
        $sqlVerificar = "SELECT COUNT(*) as total FROM CULTURAS WHERE nombre_cultura = ?";
        $stmtVerificar = $conn->prepare($sqlVerificar);
        $stmtVerificar->bind_param("s", $nombreCultura);
        $stmtVerificar->execute();
        $resultadoVerificacion = $stmtVerificar->get_result()->fetch_assoc();

        if ($resultadoVerificacion['total'] > 0) {
            // Si la cultura ya existe, redirigir con un mensaje de error
            header("Location: panel_admin.php?section=culturas&msg=duplicado");
            exit();
        } else {
            // Consulta para insertar la nueva cultura
            $sql = "INSERT INTO CULTURAS (nombre_cultura, descripcion_cultura, tipo_cultura) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nombreCultura, $descripcionCultura, $tipoCultura);

            if ($stmt->execute()) {
                header("Location: panel_admin.php?section=culturas&msg=guardado");
                exit();
            } else {
                echo "Error al guardar la cultura: " . $stmt->error;
            }

            $stmt->close();
        }

        $stmtVerificar->close();
        $conn->close();
    }
}
?>
