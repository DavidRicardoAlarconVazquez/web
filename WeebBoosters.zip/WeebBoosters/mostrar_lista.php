<?php
// Conexión a la base de datos
$host = "localhost";
$db = "inah";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener las zonas de la lista de deseos
$sql = "SELECT * FROM lista_deseos WHERE USUARIOS_id_usuario = 1"; // Asegúrate de usar el ID de usuario correcto

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='park'>";
        echo "<h2>" . $row['nombre_lista'] . "</h2>";
        // Si tienes más información para mostrar, puedes agregarla aquí
        echo "</div>";
    }
} else {
    echo "No hay zonas en la lista de deseos.";
}

$conn->close();
?>
