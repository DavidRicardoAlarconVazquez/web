<?php
include 'conexiondb.php'; 

// Si se envían datos para editar (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id_cultura']) && isset($_POST['nombreCultura']) && isset($_POST['descripcionCultura']) && isset($_POST['tipoCultura'])) {
        $idCultura = $_POST['id_cultura'];
        $nombreCultura = $_POST['nombreCultura'];
        $descripcionCultura = $_POST['descripcionCultura'];
        $tipoCultura = $_POST['tipoCultura'];

        // Verificar si el nombre de la cultura ya existe (excepto la cultura que se está editando)
        $sqlVerificar = "SELECT * FROM CULTURAS WHERE nombre_cultura = ? AND id_cultura != ?";
        $stmtVerificar = $conn->prepare($sqlVerificar);
        $stmtVerificar->bind_param("si", $nombreCultura, $idCultura);
        $stmtVerificar->execute();
        $resultadoVerificacion = $stmtVerificar->get_result();

        if ($resultadoVerificacion->num_rows > 0) {
            header("Location: panel_admin.php?section=culturas&msg=duplicado");
            exit();
        } else {
            // Consulta para actualizar la cultura
            $sql = "UPDATE CULTURAS SET nombre_cultura = ?, descripcion_cultura = ?, tipo_cultura = ? WHERE id_cultura = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $nombreCultura, $descripcionCultura, $tipoCultura, $idCultura);

            if ($stmt->execute()) {
                header("Location: panel_admin.php?section=culturas&msg=editado");
                exit();
            } else {
                echo "Error al actualizar la cultura: " . $stmt->error;
            }

            $stmt->close();
        }

        $stmtVerificar->close();
    }
}

// Si se solicita el formulario de edición (GET)
if (isset($_GET['id_cultura'])) {
    $idCultura = $_GET['id_cultura'];

    // Obtener los detalles de la cultura para editar
    $sql = "SELECT id_cultura, nombre_cultura, descripcion_cultura, tipo_cultura FROM CULTURAS WHERE id_cultura = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idCultura);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>

        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Editar Cultura</title>
            <link rel="stylesheet" href="css/style.css">
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; }
                .edit-container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); width: 400px; max-width: 100%; }
                h2 { text-align: center; margin-bottom: 20px; color: #333; }
                .form-group { margin-bottom: 15px; }
                .form-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
                .form-group input, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; }
                textarea { height: 100px; }
                button { display: block; width: 100%; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; }
                button:hover { background-color: #218838; }
            </style>
        </head>
        <body>

        <div class="edit-container">
            <h2>Editar Cultura</h2>
            <form action="editar_cultura.php" method="POST">
                <input type="hidden" name="id_cultura" value="<?php echo $row['id_cultura']; ?>">
                <div class="form-group">
                    <label for="nombreCultura">Nombre de la Cultura:</label>
                    <input type="text" id="nombreCultura" name="nombreCultura" value="<?php echo htmlspecialchars($row['nombre_cultura']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="descripcionCultura">Descripción:</label>
                    <textarea id="descripcionCultura" name="descripcionCultura" required><?php echo htmlspecialchars($row['descripcion_cultura']); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="tipoCultura">Tipo de Cultura:</label>
                    <input type="text" id="tipoCultura" name="tipoCultura" value="<?php echo htmlspecialchars($row['tipo_cultura']); ?>" required>
                </div>
                <button type="submit">Guardar Cambios</button>
            </form>
        </div>

        </body>
        </html>

        <?php
    } else {
        echo "Cultura no encontrada.";
    }

    $stmt->close();
}

$conn->close();
