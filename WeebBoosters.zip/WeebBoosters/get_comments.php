<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inah";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if (isset($_GET['zona_id'])) {
    $zona_id = intval($_GET['zona_id']);
    $sql = "SELECT nombre_usuario, comentario, fecha FROM comentarios WHERE zona_id = $zona_id ORDER BY fecha DESC";
    $result = $conn->query($sql);

    $output = "<div style='max-height: 300px; overflow-y: auto;'>";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $output .= "<div style='border-bottom: 1px solid #ccc; margin-bottom: 10px; padding-bottom: 10px;'>";
            $output .= "<strong>" . htmlspecialchars($row['nombre_usuario']) . "</strong> (" . htmlspecialchars($row['fecha']) . "):<br>";
            $output .= htmlspecialchars($row['comentario']) . "</div>";
        }
    } else {
        $output .= "No hay comentarios para esta zona.";
    }
    $output .= "</div>";
    echo $output;
}

$conn->close();
?>
