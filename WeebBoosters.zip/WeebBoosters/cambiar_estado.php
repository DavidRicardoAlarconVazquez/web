<?php
include 'conexiondb.php'; // Asegúrate de que este archivo funcione correctamente

if (isset($_GET['id']) && isset($_GET['estado'])) {
    $id_zona = (int)$_GET['id']; // Asegúrate de que sea un número
    $nuevo_estado = $_GET['estado'] === 'S' ? 'N' : 'S'; // Cambia el estado de 'S' a 'N' o viceversa

    // Actualiza el estado en la base de datos
    $sqlUpdate = "UPDATE lugar_listas SET visitado_visitaLugar = '$nuevo_estado' WHERE ZONAS_id_zona = $id_zona";

    if ($conn->query($sqlUpdate) === TRUE) {
        header("Location: deseos.php?message=Estado actualizado exitosamente"); // Redirigir a la página principal
        exit();
    } else {
        echo "Error al actualizar el estado: " . $conn->error;
    }
} else {
    echo "ID o estado no proporcionados.";
}

$conn->close();
?>
