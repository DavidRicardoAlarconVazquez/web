<?php
header('Content-Type: application/json');
$connection = new mysqli("localhost", "root", "", "inah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$id = $connection->real_escape_string($data['id']);
$visited = $connection->real_escape_string($data['visited']);

$query = "UPDATE lugar_listas SET visitado_visitaLugar = '$visited' WHERE id_lugarLista = '$id'";
$connection->query($query);

echo json_encode(["success" => true]);
$connection->close();
?>
