<?php
header('Content-Type: application/json');
$connection = new mysqli("localhost", "root", "", "inah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$query = $connection->real_escape_string($_GET['q']);

$sql = "SELECT id_zona AS id, nombre_zona AS name FROM zonas WHERE nombre_zona LIKE '%$query%'";
$result = $connection->query($sql);

$zones = [];
while ($row = $result->fetch_assoc()) {
    $zones[] = $row;
}

echo json_encode($zones);
$connection->close();
?>
