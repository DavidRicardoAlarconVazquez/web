<?php
// Iniciar la sesión
session_start();

// Destruir todas las variables de sesión
$_SESSION = array();

// Destruir la sesión
session_destroy();

// Redirigir a la página de inicio de sesión o la página de inicio
header("Location: login.php"); // Cambia a la página que desees redirigir
exit;
?>
