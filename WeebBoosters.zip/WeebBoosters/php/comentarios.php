<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario']; // Recibe el nombre del usuario desde el formulario
    $comentario = $_POST['comentario'];

    // Aquí puedes guardar el comentario en la base de datos o realizar otras acciones necesarias
    // Ejemplo de guardar en base de datos (ajustar según tu base de datos)
    
    // Asumiendo que tienes una conexión a la base de datos configurada:
    $sql = "INSERT INTO comentarios (usuario, comentario) VALUES (?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario, $comentario]);

    // Redirigir de nuevo al foro
    header("Location: ../index.php");
    exit;
}
?>
