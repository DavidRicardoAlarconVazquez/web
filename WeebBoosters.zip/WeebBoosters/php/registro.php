<?php
// Iniciar la sesión
session_start();

// Datos de conexión a la base de datos
$host = 'localhost';
$dbname = 'inah'; // Nombre de la base de datos según tu estructura SQL
$user = 'root'; // Cambia esto por tu usuario de MySQL
$pass = ''; // Cambia esto por tu contraseña de MySQL

// Conectar a la base de datos
try {
    $conexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger los datos del formulario
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $rol = 2; // Asignar el rol de 'Usuario' por defecto (suponiendo que 2 = Usuario)

    // Inicializar un array para los mensajes de error
    $errores = [];

    // Validar el nombre de usuario
    if (empty($nombre)) {
        $errores[] = "El nombre es obligatorio.";
    } elseif (strlen($nombre) < 6) {
        $errores[] = "El nombre de usuario debe tener más de 5 caracteres.";
    } elseif (!preg_match("/^[a-zA-Z0-9]+$/", $nombre)) {
        $errores[] = "El nombre de usuario no debe tener caracteres especiales.";
    } elseif (preg_match("/(admin|root|superuser|fuck|shit|bitch|asshole|bastard|dick|pussy|nigger|faggot|cunt|whore|slut|damn|crap|penis|vagina|boobs|sex|nazi|hitler|kkk|terrorist|isis|drug|killer|murderer|mierda|puta|pendejo|cabron|chingar|cabrón|puto|verga|culero|pito|culo|joto|marica|zorra|coño|polla|teta|sexo|violador|narco|asesino|matar|terrorista)/i", $nombre)) {
        $errores[] = "El nombre de usuario contiene palabras ofensivas.";
    }

    // Validar el correo
    if (empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El correo es inválido o está vacío.";
    }

    // Validar la contraseña
    if (empty($password)) {
        $errores[] = "La contraseña es obligatoria.";
    } elseif (strlen($password) < 6) {
        $errores[] = "La contraseña debe tener al menos 6 caracteres.";
    } elseif (!preg_match("/[A-Z]/", $password) || !preg_match("/[a-z]/", $password) || !preg_match("/[0-9]/", $password) || !preg_match("/[\W]/", $password)) {
        $errores[] = "La contraseña debe incluir mayúsculas, minúsculas, números y símbolos.";
    }

    if ($password !== $confirm_password) {
        $errores[] = "Las contraseñas no coinciden.";
    }

    // Verificar si el nombre de usuario o el correo ya están en uso
    if (empty($errores)) {
        $query = "SELECT COUNT(*) FROM usuarios WHERE nombre_usuario = :nombre OR correo_usuario = :correo";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':correo', $correo);
        $stmt->execute();
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            $errores[] = "El nombre de usuario o el correo ya están en uso.";
        }
    }

    // Si no hay errores, procedemos a registrar al usuario
    if (empty($errores)) {
        // No encriptar la contraseña
        try {
            $query = "INSERT INTO usuarios (nombre_usuario, correo_usuario, password_usuario, ROLES_id_roles) VALUES (:nombre, :correo, :password, :rol)";
            $stmt = $conexion->prepare($query);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':correo', $correo);
            $stmt->bindParam(':password', $password); // No cifrar la contraseña
            $stmt->bindParam(':rol', $rol);
            $stmt->execute();

            // Redirigir al usuario a la página de inicio o mostrar un mensaje de éxito
            $_SESSION['success_message'] = "Registro exitoso. Ahora puedes iniciar sesión.";
            header("Location: login.php");
            exit;
        } catch (PDOException $e) {
            $errores[] = "Error al registrar el usuario: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style-regis.css">
    <title>Registro</title>
    <style>
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            color: white;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
        }
        .error-message {
            color: red;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .success-message {
            color: green;
            font-weight: bold;
            margin-bottom: 10px;
        }
        button {
            padding: 10px 20px;
            margin-top: 10px;
        }
    </style>
</head>
<body background="../img/fondo_registro.jpg">
    <div class="container">
        <h1>Registro de Usuario</h1>

        <!-- Mostrar mensajes de error -->
        <?php if (!empty($errores)): ?>
            <div class="error-message">
                <?php foreach ($errores as $error): ?>
                    <p><?= $error ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Formulario de registro -->
        <form method="post">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" id="nombre" required>
            </div>
            <div class="form-group">
                <label for="correo">Correo Electrónico:</label>
                <input type="email" name="correo" id="correo" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirmar Contraseña:</label>
                <input type="password" name="confirm_password" id="confirm_password" required>
            </div>
            <button type="submit">Registrar</button>
        </form>

        <!-- Botón para regresar -->
        <button onclick="window.location.href='login.php';">Regresar a Iniciar Sesión</button>
    </div>
</body>
</html>
