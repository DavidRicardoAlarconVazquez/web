<?php
header('Content-Type: application/json');
$connection = new mysqli("localhost", "root", "", "inah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$zoneId = $connection->real_escape_string($data['zoneId']);

// Puedes modificar el `LISTA_DESEOS_id_lista` para reflejar la lista correspondiente a un usuario específico.
$query = "INSERT INTO lugar_listas (visitado_visitaLugar, LISTA_DESEOS_id_lista, ZONAS_id_zona) VALUES ('0', 1, '$zoneId')";
if ($connection->query($query) === TRUE) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $connection->error]);
}

$connection->close();
?>
