<?php
$servername = "localhost"; // Cambia según tu configuración
$username = "root"; // Cambia según tu configuración
$password = ""; // Cambia según tu configuración
$dbname = "inah"; // Cambia según tu configuración

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Configurar juego de caracteres
$conn->set_charset("utf8");

// Obtener el término de búsqueda
$searchTerm = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Consulta para buscar zonas arqueológicas
$sql = "SELECT * FROM zonas WHERE nombre_zona LIKE '%$searchTerm%' AND status_zona = 'A'";
$result = $conn->query($sql);

$zonas = [];

if ($result->num_rows > 0) {
    // Recoger resultados en un array
    while ($row = $result->fetch_assoc()) {
        $zonas[] = $row;
    }
}

// Devolver resultados como JSON
header('Content-Type: application/json');
echo json_encode($zonas);

// Cerrar conexión
$conn->close();
?>
