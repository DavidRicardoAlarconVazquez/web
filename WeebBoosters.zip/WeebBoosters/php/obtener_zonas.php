<?php
session_start();
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    http_response_code(403);
    exit;
}

// Aquí debes obtener las zonas de la base de datos
$zonas = [
    [
        'nombre' => 'Teotihuacán',
        'imagen' => 'img/teotihuacan.jpg',
        'descripcion' => 'Teotihuacán fue una de las ciudades más grandes...',
        'enlace' => 'teotihuacan.html'
    ],
    // Más zonas aquí...
];

// Devolver las zonas en formato JSON
header('Content-Type: application/json');
echo json_encode($zonas);
?>
