<?php
// Conexión a la base de datos
$conn = new mysqli('localhost', 'usuario', 'contraseña', 'base_de_datos');

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$usuario = $_POST['usuario'];
$comentario = $_POST['comentario'];

// Insertar comentario en la base de datos
$sql = "INSERT INTO comentarios_foro (usuario, comentario) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $usuario, $comentario);
$stmt->execute();

$stmt->close();
$conn->close();

echo "Comentario guardado exitosamente.";
?>
