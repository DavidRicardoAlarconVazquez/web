<?php
// Conexión a la base de datos
$conn = new mysqli('localhost', 'usuario', 'contraseña', 'base_de_datos');

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener comentarios
$sql = "SELECT usuario, comentario FROM comentarios_foro ORDER BY id DESC";
$result = $conn->query($sql);

// Mostrar comentarios en el foro
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<p><strong>" . htmlspecialchars($row["usuario"]) . ":</strong> " . htmlspecialchars($row["comentario"]) . "</p>";
    }
} else {
    echo "<p>No hay comentarios.</p>";
}

$conn->close();
?>
