<?php
header('Content-Type: application/json');
$connection = new mysqli("localhost", "root", "", "inah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$name = $connection->real_escape_string($data['name']);

// Debes adaptar el INSERT para añadir un parque en `lugar_listas`, asignando a `ZONAS_id_zona` una zona existente.
$query = "INSERT INTO lugar_listas (visitado_visitaLugar, LISTA_DESEOS_id_lista, ZONAS_id_zona) VALUES ('0', 1, (SELECT id_zona FROM zonas WHERE nombre_zona = '$name' LIMIT 1))";
if ($connection->query($query) === TRUE) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $connection->error]);
}

$connection->close();
?>
