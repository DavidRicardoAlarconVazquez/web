<?php
session_start();

// Datos de conexión a la base de datos
$host = 'localhost';
$dbname = 'inah'; // Cambia esto por el nombre de tu base de datos
$user = 'root'; // Cambia esto por tu usuario de MySQL
$pass = ''; // Cambia esto por tu contraseña de MySQL

// Conectar a la base de datos
try {
    $conexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Comprobación básica de login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Consulta para verificar el usuario y la contraseña
    try {
        $query = "SELECT * FROM usuarios WHERE correo_usuario = :email";
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si el usuario existe y la contraseña es correcta
        if ($user && $password == $user['password_usuario']) {
            $_SESSION["loggedin"] = true;
            $_SESSION["username"] = $user['nombre_usuario'];
            $_SESSION["profile_image"] = ($user['ROLES_id_roles'] == 1) ? "img/foto_admin.jpg" : "img/foto.jpg";

            // Identificar si el usuario es el administrador
            $_SESSION["is_admin"] = ($user['ROLES_id_roles'] == 1);

            // Redirigir a la página principal
            header("Location: ../index2.php");
            exit; // Importante para detener la ejecución después de la redirección
        } else {
            $error_message = "Correo o contraseña incorrectos.";
        }
    } catch (PDOException $e) {
        $error_message = "Error al intentar iniciar sesión: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-signin-scope" content="profile email https://www.googleapis.com/auth/business.manage">
    <meta name="google-signin-client_id" content="1023086695512-ji5o6ri474gje3910vjcgjhqqf6d2kh7.apps.googleusercontent.com">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <title>Iniciar Sesión</title>
    <style>
        body {
            background: url('../img/fondo_registro.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: white;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
            background-color: rgba(0, 0, 0, 0.7);
        }

        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: none;
        }
        
        .error-message {
            color: red;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        button {
            padding: 10px 20px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #0056b3;
        }
        
        .button-group {
            margin-top: 20px;
        }

        .google-signin {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenid@ de nuevo</h1>

        <!-- Mostrar mensaje de error si existe -->
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?= $error_message; ?></div>
        <?php endif; ?>

        <!-- Formulario para ingresar correo y contraseña -->
        <form method="post">
            <div class="form-group">
                <label for="email">Correo:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit">Ingresar</button>
        </form>

        <!-- Botones de registrar y regresar -->
        <div class="button-group">
            <button onclick="window.location.href='registro.php';">Registrar</button>
            <button onclick="window.location.href='../index.html';">Regresar</button>
        </div>

        <!-- Formulario de Google Sign-In -->
        <div class="google-signin">
            <div class="g-signin2" data-onsuccess="onSignIn" data-theme="dark"></div>
        </div>
    </div>

    <!-- Script para manejar Google Sign-In -->
    <script>
        var gmb_api_version = 'https://mybusinessaccountmanagement.googleapis.com/v1';
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            console.log('Full Name: ' + profile.getName());
            console.log("Email: " + profile.getEmail());
            var access_token = googleUser.getAuthResponse().access_token;

            var req = gmb_api_version + '/accounts';
            var xhr = new XMLHttpRequest();
            xhr.open('GET', req);
            xhr.setRequestHeader('Authorization', 'Bearer ' + access_token);

            xhr.onload = function () {
                document.body.appendChild(document.createTextNode(xhr.responseText));
            }
            xhr.send();
        }
    </script>
</body>
</html>
