<?php
header('Content-Type: application/json');
$connection = new mysqli("localhost", "root", "", "inah");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$query = "
    SELECT ll.id_lugarLista AS id_lugarLista, z.nombre_zona AS name, z.descripcion_zona AS location, ll.visitado_visitaLugar AS visitado_visitaLugar, i.url_img AS image_url 
    FROM lugar_listas ll
    JOIN zonas z ON ll.ZONAS_id_zona = z.id_zona
    JOIN imagenes i ON z.IMAGENES_id_img2 = i.id_img";

$result = $connection->query($query);

$parks = [];
while ($row = $result->fetch_assoc()) {
    $parks[] = $row;
}

echo json_encode($parks);
$connection->close();
?>
