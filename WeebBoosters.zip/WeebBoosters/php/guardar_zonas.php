<?php
include '../conexiondb.php'; // Ajusta la ruta si es necesario

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verificar la conexión
    if (!$conn) {
        die("Error de conexión a la base de datos.");
    }

    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_POST['imagen'];
    $enlace = $_POST['enlace'];
    $cultura = $_POST['cultura'];
    $estatus = $_POST['estatus'];
    $latitud = $_POST['latitud'];
    $longitud = $_POST['longitud'];

    // Verificar si todos los campos requeridos tienen datos
    if (empty($nombre) || empty($descripcion) || empty($imagen) || empty($cultura) || empty($estatus) || empty($latitud) || empty($longitud)) {
        echo "Error: Todos los campos son obligatorios.";
        exit();
    }

    // Insertar la nueva zona
    $sql = "INSERT INTO zonas (nombre_zona, descripcion_zona, CULTURAS_id_cultura2, status_zona, latitud_zona, longitud_zona) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conn->error);
    }
    $stmt->bind_param("ssisss", $nombre, $descripcion, $cultura, $estatus, $latitud, $longitud);

    if ($stmt->execute()) {
        // Obtener el último ID insertado para la zona
        $id_zona = $stmt->insert_id;

        // Insertar la imagen asociada a la zona
        $sqlImagen = "INSERT INTO imagenes (url_img, descripcion_img) VALUES (?, ?)";
        $stmtImagen = $conn->prepare($sqlImagen);
        if ($stmtImagen === false) {
            die("Error en la preparación de la consulta de la imagen: " . $conn->error);
        }
        $descripcionImagen = "Imagen de la zona: $nombre";
        $stmtImagen->bind_param("ss", $imagen, $descripcionImagen);
        $stmtImagen->execute();

        // Actualizar la referencia de imagen en la tabla zonas
        $id_img = $conn->insert_id;
        $sqlUpdateZona = "UPDATE zonas SET IMAGENES_id_img2 = ? WHERE id_zona = ?";
        $stmtUpdateZona = $conn->prepare($sqlUpdateZona);
        $stmtUpdateZona->bind_param("ii", $id_img, $id_zona);
        $stmtUpdateZona->execute();

        header("Location: ../panel_admin.php?msg=agregada&section=zonas");
        exit();
    } else {
        echo "Error al insertar la zona: " . $stmt->error;
    }

    $stmt->close();
    $stmtImagen->close();
    $stmtUpdateZona->close();
}

$conn->close();
?>
