<?php
include 'conexiondb.php'; 

$id_usuario = $_GET['id_usuario']; // Obtener ID del usuario a editar

// Obtener datos del usuario
$sql = "SELECT nombre_usuario, correo_usuario FROM USUARIOS WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc();
} else {
    echo "Usuario no encontrado.";
    exit();
}

// Manejar la edición del formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    // Actualizar los datos del usuario
    $sqlUpdate = "UPDATE USUARIOS SET nombre_usuario = ?, correo_usuario = ? WHERE id_usuario = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param("ssi", $nombre, $correo, $id_usuario);

    if ($stmtUpdate->execute()) {
        // Actualizar contraseña si se ha proporcionado una nueva
        if (!empty($contrasena)) {
            $hashedPassword = password_hash($contrasena, PASSWORD_DEFAULT);
            $sqlUpdateContrasena = "UPDATE USUARIOS SET password_usuario = ? WHERE id_usuario = ?";
            $stmtUpdateContrasena = $conn->prepare($sqlUpdateContrasena);
            $stmtUpdateContrasena->bind_param("si", $hashedPassword, $id_usuario);
            $stmtUpdateContrasena->execute();
        }
        header("Location: panel_admin.php?msg=usuario_editado&section=usuarios");
        exit();
    } else {
        echo "Error al actualizar el usuario: " . $stmtUpdate->error;
    }

    $stmtUpdate->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .edit-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            width: 400px;
            max-width: 100%;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            height: 100px;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<div class="edit-container">
    <h2>Editar Usuario</h2>
    <form action="" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($usuario['nombre_usuario']) ?>" required>
        </div>
        <div class="form-group">
            <label for="correo">Correo:</label>
            <input type="email" id="correo" name="correo" value="<?= htmlspecialchars($usuario['correo_usuario']) ?>" required>
        </div>
        <div class="form-group">
            <label for="contrasena">Nueva Contraseña (opcional):</label>
            <input type="password" id="contrasena" name="contrasena">
        </div>
        <button type="submit">Guardar Cambios</button>
    </form>
</div>

</body>
</html>
