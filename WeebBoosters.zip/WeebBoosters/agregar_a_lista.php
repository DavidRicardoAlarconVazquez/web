<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

// Verificar que se ha enviado el id_zona y id_lista
if (isset($_GET['id_zona']) && isset($_GET['lista_id'])) {
    $idZona = $_GET['id_zona'];
    $listaId = $_GET['lista_id'];

    // Comprobar si la zona ya está en la lista
    $sqlCheck = "SELECT * FROM lugar_listas WHERE ZONAS_id_zona = ? AND LISTA_Deseos_id_lista = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("ii", $idZona, $listaId);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        // Si la zona ya está en la lista
        header("Location: deseos.php?message=La zona ya está en la lista de deseos.");
        exit();
    } else {
        // Agregar la zona a la lista de deseos
        $sqlInsert = "INSERT INTO lugar_listas (ZONAS_id_zona, LISTA_Deseos_id_lista, visitado_visitaLugar) VALUES (?, ?, 'N')";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bind_param("ii", $idZona, $listaId);

        if ($stmtInsert->execute()) {
            // Redireccionar después de la inserción
            header("Location: deseos.php?message=Zona agregada a la lista de deseos exitosamente.");
        } else {
            echo "Error al agregar la zona: " . $conn->error;
        }
    }
} else {
    header("Location: deseos.php?message=Error: Parámetros faltantes.");
}
$conn->close();
?>
