<?php
// Iniciar la sesión
session_start();

// Incluir conexión a la base de datos
include 'conexiondb.php';

// Obtener la sección desde la URL, si existe
$section = isset($_GET['section']) ? $_GET['section'] : 'zonas'; // Default a 'zonas'
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_panelAdmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Panel de Administración</title>
</head>
<body>

<header>
    <h1 id="titulo"><i class="fas fa-cogs"></i> Panel de Control</h1>
    <a href="index2.php" class="btn-back" title="Regresar al Inicio">
        <i class="fas fa-home"></i> Inicio
    </a>
</header>

<!-- Menú de navegación -->
<nav id="admin-menu">
    <a href="?section=zonas" class="admin-btn"><i class="fas fa-landmark"></i> Zonas Arqueológicas</a>
    <a href="?section=culturas" class="admin-btn"><i class="fas fa-feather-alt"></i> Culturas</a>
    <a href="?section=usuarios" class="admin-btn"><i class="fas fa-users"></i> Usuarios</a>
</nav>

<!-- Contenido de las secciones -->
<div class="container" id="zonas" style="<?= $section === 'zonas' ? 'display: block;' : 'display: none;' ?>">
    <h2>Zonas Arqueológicas</h2>
    
    <?php
    // Mostrar mensajes según el valor de 'msg' en la URL
    if (isset($_GET['msg'])) {
        $msg = $_GET['msg'];
        
        if ($msg == 'duplicado') {
            echo "<p style='color: red;'>Error: La zona ya existe.</p>";
        } elseif ($msg == 'guardado') {
            echo "<p style='color: green;'>Zona guardada exitosamente.</p>";
        } elseif ($msg == 'actualizada') {
            echo "<p style='color: green;'>Zona editada exitosamente.</p>";
        } elseif ($msg == 'eliminada') {
            echo "<p style='color: green;'>Zona eliminada exitosamente.</p>";
        }
    }
    ?>

    <form action="guardar_zona.php" method="POST">
        <h3>Agregar Zonas Arqueológicas</h3>
        <div class="form-group">
            <label for="nombre">Nombre de la Zona Arqueológica:</label>
            <input type="text" id="nombre" name="nombre" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required></textarea>
        </div>
        <div class="form-group">
            <label for="imagen">URL de la Imagen:</label>
            <input type="text" id="imagen" name="imagen" required>
        </div>
        <div class="form-group">
            <label for="enlace">Enlace a más información:</label>
            <input type="url" id="enlace" name="enlace">
        </div>
        <div class="form-group">
            <label for="cultura">Tipo de Cultura:</label>
            <select id="cultura" name="cultura" required>
                <option value="" disabled selected>Selecciona una cultura</option>
                <?php
                $sqlCulturas = "SELECT * FROM culturas";
                $resultCulturas = $conn->query($sqlCulturas);
                if ($resultCulturas->num_rows > 0) {
                    while ($row = $resultCulturas->fetch_assoc()) {
                        echo "<option value='{$row['id_cultura']}'>{$row['nombre_cultura']}</option>";
                    }
                } else {
                    echo "<option value='' disabled>No hay culturas registradas.</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="estatus">Estatus:</label>
            <select id="estatus" name="estatus" required>
                <option value="" disabled selected>Selecciona un estatus</option>
                <option value="A">Activo</option>
                <option value="I">Inactivo</option>
            </select>
        </div>
        <div class="form-group">
            <label for="longitud">Longitud:</label>
            <input type="text" id="longitud" name="longitud" required>
        </div>
        <div class="form-group">
            <label for="latitud">Latitud:</label>
            <input type="text" id="latitud" name="latitud" required>
        </div>
        <button type="submit">Guardar Zona</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th>Cultura</th>
                <th>Estatus</th>
                <th>Longitud</th>
                <th>Latitud</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrar_zonas.php'; ?>
        </tbody>
    </table>
</div>

<div class="container" id="culturas" style="<?= $section === 'culturas' ? 'display: block;' : 'display: none;' ?>">
    <h2>Administrar Culturas</h2>

    <?php
    // Mostrar mensajes según el valor de 'msg' en la URL
    if (isset($_GET['msg'])) {
        $msg = $_GET['msg'];

        if ($msg == 'duplicado') {
            echo "<p style='color: red;'>Error: La cultura ya existe.</p>";
        } elseif ($msg == 'guardado') {
            echo "<p style='color: green;'>Cultura guardada exitosamente.</p>";
        } elseif ($msg == 'editado') {
            echo "<p style='color: green;'>Cultura editada exitosamente.</p>";
        } elseif ($msg == 'eliminada') {
            echo "<p style='color: green;'>Cultura eliminada exitosamente.</p>";
        }
    }
    ?>
    
    <form action="guardar_cultura.php" method="POST">
        <h3>Agregar Culturas</h3>
        <div class="form-group">
            <label for="nombreCultura">Nombre de la Cultura:</label>
            <input type="text" id="nombreCultura" name="nombreCultura" required>
        </div>
        <div class="form-group">
            <label for="descripcionCultura">Descripción:</label>
            <textarea id="descripcionCultura" name="descripcionCultura" required></textarea>
        </div>
        <div class="form-group">
            <label for="tipoCultura">Tipo de Cultura:</label>
            <input type="text" id="tipoCultura" name="tipoCultura" required>
        </div>
        <button type="submit">Guardar Cultura</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nombre de la Cultura</th>
                <th>Descripción</th>
                <th>Tipo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrar_cultura.php'; ?>
        </tbody>
    </table>
</div>

<div class="container" id="usuarios" style="<?= $section === 'usuarios' ? 'display: block;' : 'display: none;' ?>">
    <h2>Administrar Usuarios</h2>

    <?php
    // Inicializar la variable $msg si no está definida
    $msg = isset($_GET['msg']) ? $_GET['msg'] : '';

    // Mostrar mensajes según el valor de 'msg' en la URL
    if ($msg == 'usuario_eliminado') {
        echo "<p style='color: green;'>Zona eliminada exitosamente.</p>";
    } elseif ($msg == 'usuario_editado') {
        echo "<p style='color: green;'>Usuario editado exitosamente.</p>";
    }
?>

    
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php include 'mostrar_usuario.php'; ?>
        </tbody>
    </table>
</div>

<footer>
    <p> © 2024 Panel de Administración. Todos los derechos reservados.</p>
</footer>

<script>
    $(document).ready(function() {
        // Mostrar el contenedor de mensajes solo si tiene contenido
        if ($('.message-container p').length > 0) {
            $('.message-container').show(); // Mostrar si hay mensajes
        }
    });
</script>
</body>
</html>
