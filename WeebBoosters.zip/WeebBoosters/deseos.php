<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

// Obtener el filtro seleccionado
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Consulta base para obtener las zonas arqueológicas
$sqlZonas = "SELECT zonas.id_zona, zonas.nombre_zona, zonas.descripcion_zona, 
                    imagenes.url_img, culturas.nombre_cultura, 
                    zonas.status_zona, zonas.latitud_zona, 
                    zonas.longitud_zona, lugar_listas.visitado_visitaLugar 
             FROM zonas 
             LEFT JOIN imagenes ON zonas.IMAGENES_id_img2 = imagenes.id_img 
             LEFT JOIN culturas ON zonas.CULTURAS_id_cultura2 = culturas.id_cultura
             LEFT JOIN lugar_listas ON zonas.id_zona = lugar_listas.ZONAS_id_zona";

// Modificar la consulta según el filtro seleccionado
if ($filter == 'visited') {
    $sqlZonas .= " WHERE lugar_listas.visitado_visitaLugar = 'S'";
} elseif ($filter == 'not_visited') {
    $sqlZonas .= " WHERE lugar_listas.visitado_visitaLugar = 'N'";
}

$stmt = $conn->prepare($sqlZonas);
$stmt->execute();
$resultZonas = $stmt->get_result();

// Actualizar estado de visita
if (isset($_GET['action']) && isset($_GET['id'])) {
    $idZona = $_GET['id'];
    $visitado = ($_GET['action'] == 'mark_visited') ? 'S' : 'N';

    // Actualizar en la base de datos
    $sqlUpdate = "UPDATE lugar_listas SET visitado_visitaLugar = ? WHERE ZONAS_id_zona = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param("si", $visitado, $idZona);

    if ($stmtUpdate->execute()) {
        header("Location: deseos.php?message=Estado actualizado exitosamente.");
        exit();
    } else {
        echo "Error al actualizar el estado: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Deseos - Zonas Arqueológicas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/estilos.css"> <!-- Cambiado a estilos.css -->
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style-n.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Heebo', sans-serif;
            background-color: #f0f4f8;
        }
        .container {
            margin-top: 40px;
        }
        h1 {
            font-weight: 600;
            margin-bottom: 30px;
            color: #00B074; /* Cambia este color al que prefieras */
        }

        h2 {
            margin-top: 30px;
            margin-bottom: 20px;
        }
        .alert {
            margin-bottom: 20px;
        }

        /* Estilo de flotación para los elementos */    
        .floating {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            padding: 20px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .floating:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
        }

        /* Botones de filtro */
        .btn-filter {
            margin: 0 10px;
            border-radius: 50px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .btn-filter:hover {
            transform: translateY(-5px);
        }

        /* Estilo de la tabla */
        .table {
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        }

        th {
            background-color: #343a40;
            color: white;
            text-align: center;
        }

        td {
            text-align: center;
        }

        img {
            width: 100px;
            height: 75px;
            object-fit: cover;
            border-radius: 5px;
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px;
            text-align: center;
        }

        .search-box {
            margin-bottom: 30px;
        }

        .search-box input {
            width: 100%;
            max-width: 300px;
            border-radius: 50px;
            padding: 10px;
            border: 2px solid #343a40;
        }

        /* Transición suave al hacer hover en la tabla */
        tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        /* Navbar custom */
        .navbar {
            background-color: #ffffff;
        }

        .navbar .navbar-brand h1 {
            color: #00B074;
            font-size: 36px;
            font-weight: bold;
        }

        .navbar-nav .nav-link {
            color: #00B074;
            font-weight: 500;
            padding: 15px;
            text-transform: uppercase;
            transition: color 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            color: #00B074;
        }

        .navbar-toggler-icon {
            color: #00B074;
        }

        .navbar-toggler {
            border: none;
        }

        .sticky-top {
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        /* Estilos del contenedor de elementos para la lista de deseos */
        .container-lista-deseos {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .container-lista-deseos .item {
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 15px;
            transition: all 0.3s ease;
            cursor: pointer;
            max-width: 100%;
        }

        .container-lista-deseos .item:hover {
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-5px);
        }

        .container-lista-deseos .item h2 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .container-lista-deseos .item img {
            width: 100%;
            height: auto;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .container-lista-deseos .item .info_item {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: #666;
        }
        
    </style>
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
            <a class="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
                <h1 class="m-0 text" style="color: #00B074;">Lista de Deseos</h1>
            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto"> <!-- Cambiado a ms-auto -->
                    <a href="index2.php" class="nav-item nav-link">Inicio</a>
                    <a href="contact.html" class="nav-item nav-link">Buscar Zonas</a>
                    <a href="foro.html" class="nav-item nav-link">Noticias</a>
                </div>
            </div>
        </nav>
        <!-- Navbar End -->
    </div>

    <div class="container floating">

        <!-- Mensaje de éxito -->
        <?php if (isset($_GET['message'])): ?>
            <div class='alert alert-success'><?= htmlspecialchars($_GET['message']) ?></div>
        <?php endif; ?>

        <!-- Botones de filtro -->
        <div class="mb-3 text-center">
            <a href="?filter=all" class="btn btn-light btn-filter">Todas</a>
            <a href="?filter=visited" class="btn btn-success btn-filter">Visitadas</a>
            <a href="?filter=not_visited" class="btn btn-warning btn-filter">No Visitadas</a>
        </div>

        <!-- Formulario para buscar zonas -->
        <div class="search-box floating">
            <h3>Buscar Zona</h3>
            <input type="text" id="search" class="form-control" placeholder="Ingresa el nombre de la zona" required>
        </div>

        <!-- Tabla de Zonas Arqueológicas -->
        <h2>Zonas Arqueológicas</h2>
        <table class="table table-bordered" id="zonaTable">
            <thead>
                <tr>
                    <th>Nombre de la Zona</th>
                    <th>Descripción</th>
                    <th>Imagen</th>
                    <th>Cultura</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($resultZonas->num_rows > 0) {
                    while ($row = $resultZonas->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['nombre_zona']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['descripcion_zona']) . "</td>";
                        echo "<td><img src='" . htmlspecialchars($row['url_img']) . "' alt='Imagen'></td>";
                        echo "<td>" . htmlspecialchars($row['nombre_cultura']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['visitado_visitaLugar'] == 'S' ? 'Visitada' : 'No Visitada') . "</td>";
                        echo "<td>";
                        if ($row['visitado_visitaLugar'] == 'S') {
                            echo "<a href='?action=mark_not_visited&id=" . $row['id_zona'] . "' class='btn btn-warning'>Marcar como No Visitada</a>";
                        } else {
                            echo "<a href='?action=mark_visited&id=" . $row['id_zona'] . "' class='btn btn-success'>Marcar como Visitada</a>";
                        }
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No se encontraron zonas arqueológicas.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <footer>
        <p>&copy; 2024 Zonas Arqueológicas</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
