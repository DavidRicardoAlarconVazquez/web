<?php
include 'conexiondb.php'; // Conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener el ID del usuario enviado por el formulario
    $idUsuario = $_POST['id_usuario'];

    // Preparar la consulta para eliminar el usuario
    $sql = "DELETE FROM USUARIOS WHERE id_usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $idUsuario);

    // Ejecutar la consulta y verificar si fue exitosa
    if ($stmt->execute()) {
        // Redirigir al panel de administración con un mensaje de éxito
        header("Location: panel_admin.php?msg=usuario_eliminado&section=usuarios");
        exit();
    } else {
        echo "Error al eliminar el usuario: " . $stmt->error;
    }

    $stmt->close();
}

// Cerrar la conexión
$conn->close();
?>
