<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

$sqlZonas = "SELECT zonas.id_zona, zonas.nombre_zona, zonas.descripcion_zona, imagenes.url_img, culturas.nombre_cultura, zonas.status_zona, zonas.latitud_zona, zonas.longitud_zona 
             FROM zonas 
             LEFT JOIN imagenes ON zonas.IMAGENES_id_img2 = imagenes.id_img 
             LEFT JOIN culturas ON zonas.CULTURAS_id_cultura2 = culturas.id_cultura";
$resultZonas = $conn->query($sqlZonas);

if ($resultZonas->num_rows > 0) {
    while ($row = $resultZonas->fetch_assoc()) {
        echo "<tr>
                <td>{$row['nombre_zona']}</td>
                <td>{$row['descripcion_zona']}</td>
                <td><img src='{$row['url_img']}' alt='Imagen de {$row['nombre_zona']}' style='width: 100px;'></td>
                <td>{$row['nombre_cultura']}</td>
                <td>" . ($row['status_zona'] === 'A' ? 'Activo' : 'Inactivo') . "</td>
                <td>{$row['latitud_zona']}</td>
                <td>{$row['longitud_zona']}</td>
                <td>
                    <a href='editar_zona.php?id={$row['id_zona']}' class='btn btn-warning'>Editar</a>
                    <a href='eliminar_zona.php?id={$row['id_zona']}' class='btn btn-danger' onclick='return confirm(\"¿Estás seguro de que deseas eliminar esta zona?\");'>Eliminar</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='8'>No hay zonas registradas.</td></tr>";
}

$conn->close();
?>
