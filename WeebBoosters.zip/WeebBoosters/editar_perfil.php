<?php
session_start();
require 'conexiondb.php'; // Asegúrate de que la ruta sea correcta según la estructura de tu proyecto

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si la conexión a la base de datos es válida
    if (!$conn) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $id_usuario = $_SESSION['user_id'];
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $profile_image = $_FILES['profile_image'];

    // Lista básica de palabras ofensivas
    $offensive_words = [
        'fuck', 'shit', 'asshole', 'bitch', 'bastard', 'dick', 'cunt', 'pussy', 'fag', 'faggot', 'slut', 'whore', 'nigger',
        'nigga', 'chink', 'spic', 'kike', 'cracker', 'retard', 'douche', 'dickhead', 'cock', 'fucker', 'motherfucker',
        'bullshit', 'cocksucker', 'jerkoff', 'twat', 'wanker', 'prick', 'buttface', 'pendejo', 'puta', 'verga', 'chinga',
        'culero', 'picha', 'merda', 'mierda', 'puto', 'joto', 'marica', 'idiota', 'imbecil', 'cabron', 'mierdero', 'tonto',
        'estupido', 'baboso', 'gilipollas', 'mongolo', 'negro', 'negra', 'peckerwood', 'beaner', 'wetback', 'pendejada',
        'mamada', 'gaylord', 'zorra', 'maricon', 'imbecile', 'bozo', 'nazi', 'hitler', 'isis', 'terrorist', 'alqaeda', 
        'pedophile', 'pedo', 'rapist', 'molester', 'childabuser', 'killer', 'murderer', 'thief', 'prostitute', 'queer', 
        'bully', 'whitepower', 'kkk', 'racist', 'sexist', 'antisemite', 'zionist', 'gaybash', 'homophobe', 'rapist', 
        'incel', 'sjw', 'autistic', 'cripple', 'dumbass', 'stupid', 'loser', 'scumbag', 'douchebag', 'shithead', 
        'damn', 'bloody', 'hell', 'wanker', 'arse', 'bollocks', 'shag', 'git', 'twat', 'pillock'
    ];     // Reemplaza con palabras que quieras filtrar
    foreach ($offensive_words as $word) {
        if (stripos($username, $word) !== false) {
            echo "<script>alert('El nombre de usuario contiene palabras inapropiadas.'); window.location.href='index2.php';</script>";
            exit;
        }
    }

    // Verificar si las contraseñas coinciden
    if ($password !== $confirm_password) {
        echo "<script>alert('Las contraseñas no coinciden.'); window.location.href='index2.php';</script>";
        exit;
    }

    // Verificar si el nombre de usuario es válido
    if (!preg_match("/^[a-zA-Z0-9_]+$/", $username)) {
        echo "<script>alert('El nombre de usuario no es válido.'); window.location.href='index2.php';</script>";
        exit;
    }

    // Verificar si el nombre de usuario o el correo electrónico ya existen en otro usuario
    $stmt = $conn->prepare("SELECT id_usuario FROM usuarios WHERE (nombre_usuario = ? OR correo_usuario = ?) AND id_usuario != ?");
    $stmt->bind_param("ssi", $username, $email, $id_usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "<script>alert('El nombre de usuario o el correo electrónico ya están en uso.'); window.location.href='index2.php';</script>";
        exit;
    }
    $stmt->close();

    // Verifica si se ha subido una nueva imagen de perfil
    $profile_image_path = $_SESSION['profile_image']; // Ruta actual de la imagen
    if (isset($profile_image) && $profile_image['size'] > 0) {
        $target_dir = "img/";
        $file_name = uniqid() . "_" . basename($profile_image["name"]); // Añadir un identificador único para evitar conflictos
        $target_file = $target_dir . $file_name;

        // Mover la imagen a la carpeta de destino y validar
        if (move_uploaded_file($profile_image["tmp_name"], $target_file)) {
            $profile_image_path = "img/" . $file_name; // Ruta relativa para guardar en la DB
        } else {
            echo "<script>alert('Error al cargar la imagen de perfil.'); window.location.href='index2.php';</script>";
            exit;
        }
    }

    // Preparar la actualización del usuario
    $hashed_password = !empty($password) ? password_hash($password, PASSWORD_DEFAULT) : null;

    $query = "UPDATE usuarios SET nombre_usuario = ?, correo_usuario = ?, profile_image = ?";
    $params = [$username, $email, $profile_image_path];
    $types = "sss";

    if ($hashed_password) {
        $query .= ", password_usuario = ?";
        $params[] = $hashed_password;
        $types .= "s";
    }

    $query .= " WHERE id_usuario = ?";
    $params[] = $id_usuario;
    $types .= "i";

    // Preparar y ejecutar la consulta
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        if ($stmt->execute()) {
            // Actualizar los valores de sesión
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['profile_image'] = $profile_image_path;
            echo "<script>alert('Perfil actualizado exitosamente.'); window.location.href='index2.php';</script>";
            exit;
        } else {
            echo "<script>alert('Error al actualizar el perfil: " . $stmt->error . "'); window.location.href='index2.php';</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Error en la preparación de la consulta: " . $conn->error . "'); window.location.href='index2.php';</script>";
    }

    // Cerrar la conexión
    $conn->close();
}
?>
