<?php
include 'conexiondb.php'; 

if (isset($_POST['id_cultura'])) { 
    $id_cultura = $_POST['id_cultura'];

    // Primero, establecer el campo CULTURAS_id_cultura2 en NULL para las zonas asociadas a esta cultura
    $sqlUpdateZonas = "UPDATE ZONAS SET CULTURAS_id_cultura2 = NULL WHERE CULTURAS_id_cultura2 = ?";
    $stmtUpdateZonas = $conn->prepare($sqlUpdateZonas);
    $stmtUpdateZonas->bind_param("i", $id_cultura);
    
    if ($stmtUpdateZonas->execute()) {
        // Ahora, eliminar la cultura
        $sqlDeleteCultura = "DELETE FROM CULTURAS WHERE id_cultura = ?";
        $stmtDeleteCultura = $conn->prepare($sqlDeleteCultura);
        $stmtDeleteCultura->bind_param("i", $id_cultura);
        
        if ($stmtDeleteCultura->execute()) {
            header("Location: panel_admin.php?msg=eliminada&section=culturas");
            exit();
        } else {
            echo "Error al eliminar la cultura: " . $stmtDeleteCultura->error;
        }

        $stmtDeleteCultura->close();
    } else {
        echo "Error al actualizar las zonas: " . $stmtUpdateZonas->error;
    }

    $stmtUpdateZonas->close();
} else {
    echo "No se proporcionó un ID de cultura para eliminar.";
}

$conn->close();
?>
