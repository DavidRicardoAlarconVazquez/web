<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inah";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Configurar el juego de caracteres para evitar problemas de codificación
$conn->set_charset("utf8mb4");

// Obtener el nombre del usuario desde la sesión (asumiendo que el usuario ha iniciado sesión)
$nombre_usuario = isset($_SESSION['nombre_usuario']) ? $_SESSION['nombre_usuario'] : '';

// Obtener todas las culturas para los botones de filtro
$sql_culturas = "SELECT id_cultura, nombre_cultura FROM culturas";
$result_culturas = $conn->query($sql_culturas);
$culturas = [];
while ($row = $result_culturas->fetch_assoc()) {
    $culturas[] = $row;
}

// Verificar si se pasó un nombre de cultura desde la URL o desde el index
$nombre_cultura = isset($_GET['nombre_cultura']) ? $_GET['nombre_cultura'] : null;

// Construir la consulta según si se pasa un nombre de cultura o no
if ($nombre_cultura) {
    $sql = "SELECT zonas.*, culturas.nombre_cultura, imagenes.url_img, imagenes.descripcion_img FROM zonas 
            INNER JOIN culturas ON zonas.CULTURAS_id_cultura2 = culturas.id_cultura
            INNER JOIN imagenes ON zonas.IMAGENES_id_img2 = imagenes.id_img
            WHERE culturas.nombre_cultura LIKE ?";
    $stmt = $conn->prepare($sql);
    $param = "%" . $nombre_cultura . "%";
    $stmt->bind_param("s", $param);
} else {
    $sql = "SELECT zonas.*, culturas.nombre_cultura, imagenes.url_img, imagenes.descripcion_img FROM zonas 
            INNER JOIN culturas ON zonas.CULTURAS_id_cultura2 = culturas.id_cultura
            INNER JOIN imagenes ON zonas.IMAGENES_id_img2 = imagenes.id_img";
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();

// Agrupar las zonas por cultura
$zonas_por_cultura = [];
while ($row = $result->fetch_assoc()) {
    $zonas_por_cultura[$row['nombre_cultura']][] = $row;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zonas por Culturas</title>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@700;800&display=swap" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
    .cultura-buttons { margin-bottom: 20px; text-align: center; }
    .cultura-button { 
    padding: 10px 20px; /* Tamaño normal del botón */
    font-size: 16px; /* Tamaño normal de la fuente */
    border: none; 
    background-color: #333; 
    color: white; 
    cursor: pointer; 
    border-radius: 5px; 
    margin: 5px; 
    transition: transform 0.3s, background-color 0.3s, color 0.3s; /* Suave transición */
}
.cultura-button:hover { 
    transform: scale(1.1); /* Agrandar el botón al pasar el cursor */
    background-color: white; /* Cambio a blanco al pasar el cursor */
    color: #333; /* Cambio de color del texto para mejor contraste */
}

    .cultura-section { margin-bottom: 30px; text-align: center; } /* Ajuste para centrar */
    .cultura-title { 
    font-size: 24px; 
    margin-bottom: 10px; 
    background-color: transparent; /* Cambiado a transparente */
    color: #333; /* Ajusta el color del texto si es necesario */
    padding: 10px; 
    border-radius: 5px; 
    display: inline-block;
    }

    .zonas-container { display: flex; flex-wrap: wrap; justify-content: space-between; }
    .zona-card { width: 23%; background-color: #fff; border-radius: 5px; margin-bottom: 20px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); text-align: center; padding-bottom: 10px; overflow: hidden; position: relative; }
    .zona-image-container { position: relative; perspective: 1000px; height: 200px; overflow: hidden; }
    .zona-image-inner { position: absolute; width: 100%; height: 100%; transition: transform 0.6s; transform-style: preserve-3d; }
    .zona-card:hover .zona-image-inner { transform: rotateY(180deg); }
    .zona-front, .zona-back {
        position: absolute; width: 100%; height: 100%; backface-visibility: hidden; border-top-left-radius: 5px; border-top-right-radius: 5px;
    }
    .zona-front img { max-width: 100%; height: 100%; }
    .zona-back { background-color: #333; color: white; display: flex; align-items: center; justify-content: center; padding: 10px; transform: rotateY(180deg); }
    .zona-description { padding: 10px; }
    .zona-description h3 { margin-bottom: 5px; font-size: 18px; }
    .btn-group { margin-top: 10px; display: flex; justify-content: space-evenly; }
    .btn-group button { width: 45%; padding: 8px; }
    .comment-popup, .view-comments-popup { display: none; position: fixed; bottom: 0; right: 0; width: 400px; background: white; border: 1px solid #ccc; padding: 15px; box-shadow: 0 0 10px rgba(0,0,0,0.3); z-index: 1000; border-radius: 10px; }
    .comment-popup h3, .view-comments-popup h3 { margin-top: 0; }
    .comment-popup textarea { width: 100%; height: 100px; border-radius: 5px; padding: 10px; border: 1px solid #ccc; }
    .comment-popup input { width: 100%; padding: 8px; border-radius: 5px; margin-bottom: 10px; }
    .comment-popup button, .view-comments-popup button { padding: 8px 15px; border: none; background-color: #4CAF50; color: white; cursor: pointer; border-radius: 5px; }
    .comment-popup button:hover, .view-comments-popup button:hover { background-color: #45a049; }
</style>

    <script>
        function showCommentForm(zonaId) {
            document.getElementById('comment-zona-id').value = zonaId;
            document.getElementById('comment-popup').style.display = 'block';
        }

        function closeCommentForm() {
            document.getElementById('comment-popup').style.display = 'none';
        }

        function submitComment() {
            const zonaId = document.getElementById('comment-zona-id').value;
            const nombreUsuario = "<?php echo htmlspecialchars($nombre_usuario); ?>";
            const comentario = document.getElementById('comment-text').value;

            if (comentario.trim() === "") {
                alert("Por favor, ingresa un comentario.");
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.open("POST", "submit_comment.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    alert("Comentario guardado exitosamente.");
                    closeCommentForm();
                }
            };
            xhr.send(`zona_id=${zonaId}&nombre_usuario=${encodeURIComponent(nombreUsuario)}&comentario=${encodeURIComponent(comentario)}`);
        }

        function showComments(zonaId) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", `get_comments.php?zona_id=${zonaId}`, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('comments-content').innerHTML = xhr.responseText;
                    document.getElementById('view-comments-popup').style.display = 'block';
                }
            };
            xhr.send();
        }

        function closeCommentsPopup() {
            document.getElementById('view-comments-popup').style.display = 'none';
        }
    </script>
</head>
<body>
<div class="container-xxl bg-white p-0">
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index2.php" class="navbar-brand d-flex align-items-center text-center py-0 px-4 px-lg-5">
            <h1 class="m-0 text-primary">Zonas Arqueológicas</h1>
        </a>
    </nav>
    <br><br><br>

    <div class="cultura-buttons">
        <?php foreach ($culturas as $cultura): ?>
            <a href="?nombre_cultura=<?php echo urlencode($cultura['nombre_cultura']); ?>">
                <button class="cultura-button">Cultura: <?php echo htmlspecialchars($cultura['nombre_cultura']); ?></button>
            </a>
        <?php endforeach; ?>
        <a href="?"><button class="cultura-button">Todas las Culturas</button></a>
    </div>

    <?php foreach ($zonas_por_cultura as $nombre_cultura => $zonas): ?>
        <div class="cultura-section">
            <div class="cultura-title">Cultura: <?php echo htmlspecialchars($nombre_cultura); ?></div>
            <div class="zonas-container">
                <?php foreach ($zonas as $zona): ?>
                    <div class="zona-card">
                        <div class="zona-image-container">
                            <div class="zona-image-inner">
                                <div class="zona-front">
                                    <img src="<?php echo htmlspecialchars($zona['url_img']); ?>" alt="<?php echo htmlspecialchars($zona['descripcion_img']); ?>">
                                </div>
                                <div class="zona-back">
                                    <p><?php echo htmlspecialchars($zona['descripcion_img']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="zona-description">
                            <h3><?php echo htmlspecialchars($zona['nombre_zona']); ?></h3>
                            <p><?php echo htmlspecialchars($zona['descripcion_zona']); ?></p>
                            <div class="btn-group">
                                <button onclick="showComments('<?php echo $zona['id_zona']; ?>')" class="btn btn-primary">Ver Comentarios</button>
                                <button onclick="showCommentForm('<?php echo $zona['id_zona']; ?>')" class="btn btn-secondary">Dejar un Comentario</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div id="comment-popup" class="comment-popup">
    <h3>Agregar Comentario</h3>
    <input type="hidden" id="comment-zona-id">
    <textarea id="comment-text" placeholder="Tu Comentario"></textarea><br><br>
    <button onclick="submitComment()">Enviar</button>
    <button onclick="closeCommentForm()">Cerrar</button>
</div>

<div id="view-comments-popup" class="view-comments-popup">
    <h3>Comentarios</h3>
    <div id="comments-content"></div>
    <button onclick="closeCommentsPopup()">Cerrar</button>
</div>
</body>
</html>
