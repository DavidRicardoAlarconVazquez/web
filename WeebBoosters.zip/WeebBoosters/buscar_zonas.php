<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

// Verificar si se ha enviado la búsqueda
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];

    // Consulta para obtener las zonas arqueológicas que contienen la cadena de búsqueda
    $sqlZonas = "SELECT zonas.id_zona, zonas.nombre_zona, zonas.descripcion_zona, imagenes.url_img, culturas.nombre_cultura, lugar_listas.visitado_visitaLugar 
                 FROM zonas 
                 LEFT JOIN imagenes ON zonas.IMAGENES_id_img2 = imagenes.id_img 
                 LEFT JOIN culturas ON zonas.CULTURAS_id_cultura2 = culturas.id_cultura
                 LEFT JOIN lugar_listas ON zonas.id_zona = lugar_listas.ZONAS_id_zona
                 WHERE zonas.nombre_zona LIKE ?";

    $stmt = $conn->prepare($sqlZonas);
    $likeSearch = '%' . $searchTerm . '%'; // Cambiar para buscar en cualquier parte del nombre
    $stmt->bind_param("s", $likeSearch);
    $stmt->execute();
    $resultZonas = $stmt->get_result();

    // Mostrar las zonas en formato HTML
    if ($resultZonas->num_rows > 0) {
        while ($row = $resultZonas->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['nombre_zona']) . "</td>
                    <td>" . htmlspecialchars($row['descripcion_zona']) . "</td>
                    <td><img src='" . htmlspecialchars($row['url_img']) . "' alt='Imagen de " . htmlspecialchars($row['nombre_zona']) . "' style='width: 100px;'></td>
                    <td>" . htmlspecialchars($row['nombre_cultura']) . "</td>
                    <td>" . ($row['visitado_visitaLugar'] === 'S' ? 'Visitada' : 'No Visitada') . "</td>
                    <td>
                        <a href='?action=" . ($row['visitado_visitaLugar'] === 'S' ? 'mark_not_visited' : 'mark_visited') . "&id=" . htmlspecialchars($row['id_zona']) . "' class='btn btn-success'>" . ($row['visitado_visitaLugar'] === 'S' ? 'Marcar como No Visitada' : 'Marcar como Visitada') . "</a>
                    </td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No hay zonas registradas.</td></tr>";
    }
}

$conn->close();
?>
