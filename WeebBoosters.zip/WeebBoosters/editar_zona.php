<?php
include 'conexiondb.php'; 

$id_zona = $_GET['id'];

// Obtener datos de la zona
$sql = "SELECT ZONAS.id_zona, ZONAS.nombre_zona, ZONAS.descripcion_zona, IMAGENES.url_img, 
               ZONAS.CULTURAS_id_cultura2, ZONAS.status_zona, ZONAS.latitud_zona, ZONAS.longitud_zona 
        FROM ZONAS 
        LEFT JOIN IMAGENES ON ZONAS.IMAGENES_id_img2 = IMAGENES.id_img 
        WHERE ZONAS.id_zona = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_zona);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $zona = $result->fetch_assoc();
} else {
    echo "Zona no encontrada.";
    exit();
}

// Manejar la edición del formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_POST['imagen'];
    $cultura = $_POST['cultura'];
    $estatus = $_POST['estatus'];
    $longitud = $_POST['longitud'];
    $latitud = $_POST['latitud'];

    // Verificar si el nombre de la zona ya existe (excluyendo la zona actual)
    $sqlCheck = "SELECT id_zona FROM ZONAS WHERE nombre_zona = ? AND id_zona != ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("si", $nombre, $id_zona);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        // Si ya existe una zona con ese nombre, redirigir con un mensaje
        header("Location: panel_admin.php?msg=duplicado&section=zonas");
        exit();
    } else {
        // Actualizar la zona
        $sqlUpdate = "UPDATE ZONAS SET nombre_zona = ?, descripcion_zona = ?, CULTURAS_id_cultura2 = ?, 
                      status_zona = ?, latitud_zona = ?, longitud_zona = ? WHERE id_zona = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->bind_param("ssissii", $nombre, $descripcion, $cultura, $estatus, $latitud, $longitud, $id_zona);
        
        if ($stmtUpdate->execute()) {
            // Actualizar imagen si se proporciona una nueva
            if (!empty($imagen)) {
                $sqlImagenUpdate = "UPDATE IMAGENES SET url_img = ? WHERE id_img = (SELECT IMAGENES_id_img2 FROM ZONAS WHERE id_zona = ?)";
                $stmtImagenUpdate = $conn->prepare($sqlImagenUpdate);
                $stmtImagenUpdate->bind_param("si", $imagen, $id_zona);
                $stmtImagenUpdate->execute();
            }
            header("Location: panel_admin.php?msg=actualizada&section=zonas"); // Cambia 'msg=editado' a 'msg=actualizada'
            exit();
        } else {
            echo "Error: " . $stmtUpdate->error;
        }

        // Cerrar $stmtUpdate si fue definido
        if (isset($stmtUpdate)) {
            $stmtUpdate->close();
        }
    }

    // Cerrar $stmtCheck
    $stmtCheck->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Zona</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background-color: #f4f4f9; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
        }
        .edit-container { 
            background-color: #fff; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); 
            width: 400px; 
            max-width: 100%; 
        }
        h2 { 
            text-align: center; 
            margin-bottom: 20px; 
            color: #333; 
        }
        .form-group { 
            margin-bottom: 15px; 
        }
        .form-group label { 
            display: block; 
            margin-bottom: 5px; 
            font-weight: bold; 
            color: #555; 
        }
        .form-group input, .form-group textarea, .form-group select { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ccc; 
            border-radius: 4px; 
            font-size: 16px; 
        }
        textarea { 
            height: 100px; 
        }
        button { 
            display: block; 
            width: 100%; 
            padding: 10px; 
            background-color: #28a745; 
            color: white; 
            border: none; 
            border-radius: 4px; 
            font-size: 16px; 
            cursor: pointer; 
        }
        button:hover { 
            background-color: #218838; 
        }
    </style>
</head>
<body>

<div class="edit-container">
    <h2>Editar Zona Arqueológica</h2>
    <form action="" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre de la Zona:</label>
            <input type="text" id="nombre" name="nombre" value="<?= htmlspecialchars($zona['nombre_zona']) ?>" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required><?= htmlspecialchars($zona['descripcion_zona']) ?></textarea>
        </div>
        <div class="form-group">
            <label for="imagen">URL de la Imagen:</label>
            <input type="text" id="imagen" name="imagen" value="<?= htmlspecialchars($zona['url_img']) ?>">
        </div>
        <div class="form-group">
            <label for="cultura">Tipo de Cultura:</label>
            <select id="cultura" name="cultura" required>
                <option value="" disabled>Selecciona una cultura</option>
                <?php
                // Obtener las culturas
                $sqlCulturas = "SELECT * FROM CULTURAS";
                $resultCulturas = $conn->query($sqlCulturas);

                if ($resultCulturas->num_rows > 0) {
                    while ($row = $resultCulturas->fetch_assoc()) {
                        $selected = ($row['id_cultura'] == $zona['CULTURAS_id_cultura2']) ? 'selected' : '';
                        echo "<option value='{$row['id_cultura']}' $selected>{$row['nombre_cultura']}</option>";
                    }
                } else {
                    echo "<option value='' disabled>No hay culturas registradas.</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="estatus">Estatus:</label>
            <select id="estatus" name="estatus" required>
                <option value="A" <?= $zona['status_zona'] === 'A' ? 'selected' : '' ?>>Activo</option>
                <option value="I" <?= $zona['status_zona'] === 'I' ? 'selected' : '' ?>>Inactivo</option>
            </select>
        </div>
        <div class="form-group">
            <label for="longitud">Longitud:</label>
            <input type="text" id="longitud" name="longitud" value="<?= htmlspecialchars($zona['longitud_zona']) ?>" required>
        </div>
        <div class="form-group">
            <label for="latitud">Latitud:</label>
            <input type="text" id="latitud" name="latitud" value="<?= htmlspecialchars($zona['latitud_zona']) ?>" required>
        </div>
        <button type="submit">Guardar cambios</button>
    </form>
</div>

</body>
</html>
