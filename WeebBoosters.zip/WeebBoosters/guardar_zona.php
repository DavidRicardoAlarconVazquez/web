<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y esté en la ubicación correcta

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $imagen = $_POST['imagen'];
    $descripcionImagen = "Descripción de la imagen"; // Puedes ajustar esto según sea necesario
    $cultura = $_POST['cultura'];
    $estatus = $_POST['estatus']; // Obtener el estatus
    $latitud = $_POST['latitud']; // Obtener la latitud
    $longitud = $_POST['longitud']; // Obtener la longitud

    // Verificar si la zona ya existe
    $sqlCheck = "SELECT * FROM ZONAS WHERE nombre_zona = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param("s", $nombre);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        // La zona ya existe
        header("Location: panel_admin.php?msg=ya_existe&section=zonas");
        exit();
    }

    // Agregar la nueva zona con latitud y longitud
    $sql = "INSERT INTO ZONAS (nombre_zona, descripcion_zona, CULTURAS_id_cultura2, status_zona, latitud_zona, longitud_zona) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssisss", $nombre, $descripcion, $cultura, $estatus, $latitud, $longitud);
    
    if ($stmt->execute()) {
        // Obtener el último ID insertado para la zona
        $id_zona = $stmt->insert_id;

        // Agregar la imagen
        $sqlImagen = "INSERT INTO IMAGENES (url_img, descripcion_img) VALUES (?, ?)";
        $stmtImagen = $conn->prepare($sqlImagen);
        $stmtImagen->bind_param("ss", $imagen, $descripcionImagen);
        if ($stmtImagen->execute()) {
            // Obtener el id_img de la imagen insertada
            $id_img = $stmtImagen->insert_id;

            // Actualizar la zona con el id de la imagen
            $sqlUpdateZona = "UPDATE ZONAS SET IMAGENES_id_img2 = ? WHERE id_zona = ?";
            $stmtUpdateZona = $conn->prepare($sqlUpdateZona);
            $stmtUpdateZona->bind_param("ii", $id_img, $id_zona);
            $stmtUpdateZona->execute();
        }

        header("Location: panel_admin.php?msg=agregada&section=zonas");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $stmtImagen->close();
    $conn->close();
}
?>
