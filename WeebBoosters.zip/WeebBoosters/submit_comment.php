<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inah";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

if (isset($_POST['zona_id']) && isset($_POST['nombre_usuario']) && isset($_POST['comentario'])) {
    $zona_id = intval($_POST['zona_id']);
    $nombre_usuario = $conn->real_escape_string($_POST['nombre_usuario']);
    $comentario = $conn->real_escape_string($_POST['comentario']);

    $sql = "INSERT INTO comentarios (zona_id, nombre_usuario, comentario) VALUES ('$zona_id', '$nombre_usuario', '$comentario')";

    if ($conn->query($sql) === TRUE) {
        echo "Comentario guardado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
