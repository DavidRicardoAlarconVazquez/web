<?php
// Datos de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";  // Sin contraseña
$dbname = "inah";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener datos del formulario
$id_zona = $_POST['id_zona'];
$visitado = $_POST['visitado'];

// Actualizar el estado de la zona en la base de datos
$sql_update = "UPDATE lugar_listas SET visitado_visitaLugar = ? WHERE ZONAS_id_zona = ?";
$stmt = $conn->prepare($sql_update);
$stmt->bind_param("si", $visitado, $id_zona);

if ($stmt->execute()) {
    echo "Zona actualizada.";
} else {
    echo "Error al actualizar la zona.";
}

$stmt->close();
$conn->close();
?>
