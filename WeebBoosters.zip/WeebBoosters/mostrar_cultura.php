<?php
include 'conexiondb.php'; // Asegúrate de que este archivo exista y funcione correctamente

// Consulta para obtener todas las culturas, incluyendo el tipo
$sql = "SELECT id_cultura, nombre_cultura, descripcion_cultura, tipo_cultura FROM CULTURAS";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Mostrar cada cultura en una fila
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['nombre_cultura']}</td>
                <td>{$row['descripcion_cultura']}</td>
                <td>{$row['tipo_cultura']}</td>
                <td>
                    <form action='editar_cultura.php' method='GET' style='display:inline;'>
                        <input type='hidden' name='id_cultura' value='{$row['id_cultura']}'>
                        <button type='submit'>Editar</button>
                    </form>
                    <form action='eliminar_cultura.php' method='POST' onsubmit='return confirm(\"¿Estás seguro de que deseas eliminar esta cultura?\");' style='display:inline;'>
                        <input type='hidden' name='id_cultura' value='{$row['id_cultura']}'>
                        <button type='submit'>Eliminar</button>
                    </form>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4'>No hay culturas registradas.</td></tr>";
}

$conn->close();
?>
