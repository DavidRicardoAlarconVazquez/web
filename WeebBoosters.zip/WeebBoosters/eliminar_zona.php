<?php
include 'conexiondb.php';

if (isset($_GET['id'])) {
    $id_zona = $_GET['id'];

    // Primero, eliminar la imagen asociada a la zona
    $sqlDeleteImagen = "DELETE FROM IMAGENES WHERE id_img = (SELECT IMAGENES_id_img2 FROM ZONAS WHERE id_zona = ?)";
    $stmtDeleteImagen = $conn->prepare($sqlDeleteImagen);
    $stmtDeleteImagen->bind_param("i", $id_zona);
    
    if ($stmtDeleteImagen->execute()) {
        // Ahora, eliminar la zona
        $sqlDeleteZona = "DELETE FROM ZONAS WHERE id_zona = ?";
        $stmtDeleteZona = $conn->prepare($sqlDeleteZona);
        $stmtDeleteZona->bind_param("i", $id_zona);
        
        if ($stmtDeleteZona->execute()) {
            header("Location: panel_admin.php?msg=eliminada&section=zonas");
            exit();
        } else {
            echo "Error al eliminar la zona: " . $stmtDeleteZona->error;
        }

        $stmtDeleteZona->close();
    } else {
        echo "Error al eliminar las imágenes: " . $stmtDeleteImagen->error;
    }

    $stmtDeleteImagen->close();
} else {
    echo "No se proporcionó un ID de zona para eliminar.";
}

$conn->close();
?>
